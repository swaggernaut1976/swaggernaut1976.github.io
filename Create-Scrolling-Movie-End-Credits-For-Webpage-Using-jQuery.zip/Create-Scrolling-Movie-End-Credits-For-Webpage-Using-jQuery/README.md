End Credits in jQuery
==========

Movie end credits for your website!

See demo at http://epichail.com/endcredits/fim.html
